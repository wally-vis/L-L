# How Do You Know Your AI Insights Are Correct?
*Spoiler: You don't. But here's how to get uncomfortably close.*

──────────────────────────────────────────────────

## The Uncomfortable Truth

> "Can you trust your LLM?" — Every conference speaker, 2025

**The honest answer:** No. Not blindly. Ever.

| What LLMs Do Well | What LLMs Do Badly |
|---|---|
| Generate fluent, coherent text | Guarantee factual accuracy |
| Follow structured output formats | Consistent results across runs |
| Summarise and extract patterns | Mathematical precision |
| Creative generation and brainstorming | Know when they're wrong |
| Follow instructions (mostly) | Admit uncertainty honestly |

**Common failure modes:**
- Hallucinate data that sounds plausible but is fabricated
- Truncate responses silently (you get 80% of the answer)
- Return malformed JSON (missing brackets, wrong types)
- Confidently cite numbers that don't exist in the source
- Produce different outputs from identical prompts (non-determinism)
- Fabricate reasoning in Chain-of-Thought that sounds logical but is wrong

**Human-in-the-Loop doesn't scale.** Manual review is infeasible at volume, reviewers fatigue, and it defeats the purpose of automation.

**So what do we do?**

──────────────────────────────────────────────────

## The Mindset Shift

| Old Thinking | New Thinking |
|---|---|
| "Is this output correct?" | "Can I prove this was validated?" |
| "Trust the AI" | "Trust the evaluation system" |
| "Human reviews everything" | "Automated evaluation + targeted human review" |
| "Ship and hope" | "Ship what passed, log what didn't" |
| "The AI said it, must be true" | "The AI said it, let's verify" |
| "We need 100% accuracy" | "We need provable validation rigour" |

**The goal is not perfect AI. The goal is provably validated AI.**

> "Prove we validated rigorously and can trace why it was approved."

──────────────────────────────────────────────────

## The Three Pillars

| Pillar | Purpose | Question It Answers |
|--------|---------|-------------------|
| **Evaluation** | Catch errors before users see them | "Is this output good enough to ship?" |
| **Observability** | Diagnose failures after they happen | "What went wrong and where?" |
| **Explainability** | Decisions can be understood and audited | "Why did the system produce this output?" |

If you nail all three, you can always answer: *"Why did the system produce this output, and how do we know it was validated?"*

──────────────────────────────────────────────────

## Core Principles

| Principle | What It Means | Why It Matters |
|-----------|-------------|---------------|
| **Traceable** | Every output links to inputs and reasoning | Audit trail for every decision |
| **Separate generation from evaluation** | Generators optimise for fluency; evaluators optimise for accuracy | Prevents the fox guarding the henhouse |
| **Make reasoning visible** | Use Chain-of-Thought for evaluation and logging | Exposes flaws a direct answer would hide |
| **Handle failure gracefully** | Expect non-determinism; use quality checks and retries | Systems that expect failure are resilient |
| **Log what matters** | Enough to debug, iterate, and audit | You can't improve what you can't measure |
| **Filter by confidence** | Binary, scored, or ranked based on use case | Not all outputs deserve to ship |

──────────────────────────────────────────────────

## Chain-of-Thought (CoT) — Your Audit Trail

CoT forces the model to reason step-by-step, making decisions auditable.

### Why CoT Matters

| Without CoT | With CoT |
|---|---|
| Verdict: "EXCLUDE" | Verdict: "EXCLUDE" |
| (Why? Who knows.) | Reasoning: "Source shows utilization at 92%. Suggestion assumes spare truck capacity. No spare capacity exists. Not viable." |

**Benefits:**
- Exposes reasoning flaws a direct answer would hide
- Creates audit trail for approvals and rejections
- Improves accuracy — models perform better when they reason first
- Enables prompt improvement from logged failures
- Makes debugging possible ("Why did the validator exclude this?")

### How to Use CoT

> **Important:** AI Builder doesn't support extracting native CoT from reasoning models. You must prompt the model to return reasoning as part of its JSON output.

**Example prompt approach:**
```
Evaluate this [item] against the source data.

Think through:
- What claim is being made?
- What evidence would support it?
- Is that evidence present in the source data?
- Does the evidence support or contradict the claim?

Return JSON with your reasoning and verdict.
```

**Example output:**
```json
{
  "chain_of_thought": "The suggestion assumes truck capacity is available. Source shows utilization at 92%, no spare capacity. Not viable.",
  "verdict": "EXCLUDE",
  "reason": "Truck utilization too high — no spare capacity for redeployment"
}
```

### What to Log from CoT

| Log Item | Purpose |
|----------|---------|
| Validation decisions (why included/excluded) | Audit trail |
| Ranking decisions (why prioritised) | Explain ordering to stakeholders |
| Quality gate failures (what specifically failed) | Debugging and prompt improvement |
| Mathematical re-derivations | Verify the model's calculations |
| Conflict detection reasoning | Understand cross-component issues |

──────────────────────────────────────────────────

## Common Failure Modes & Detection

### Failure Detection Table

| Failure Mode | How to Detect | Cost to Check |
|---|---|---|
| Truncated output | Length below threshold | Free (string length) |
| Missing fields | Schema validation | Free (JSON parse) |
| Malformed JSON | Parse error | Free (try/catch) |
| Wrong data types | Type checking | Free (typeof) |
| Wrong format | Format validation | Free (regex/pattern) |
| Hallucinated data | Cross-reference source | Cheap (lookup) |
| Math errors | Re-derive from source | Cheap (calculation) |
| Contradictory claims | Cross-component checks | Expensive (LLM) |
| Reasoning errors | Semantic evaluation | Expensive (LLM) |

### Key Insight
Most failures are detectable with cheap deterministic checks. Don't pay for an LLM evaluator if a regex would catch it first.

──────────────────────────────────────────────────

## Quality Gates — The Bouncer at the Door

Run deterministic checks BEFORE expensive semantic evaluation:

| Check | Type | Cost | What It Catches |
|-------|------|------|----------------|
| Output length above minimum | Deterministic | Free | Truncated responses |
| Required JSON keys present | Deterministic | Free | Missing fields |
| Data types correct | Deterministic | Free | Type mismatches |
| Values within expected ranges | Deterministic | Free | Obvious hallucinations |
| Cited values exist in source | Lookup | Cheap | Fabricated references |
| Mathematical re-derivation | Calculation | Cheap | Arithmetic errors |
| Semantic correctness | LLM evaluation | Expensive | Subtle reasoning errors |

**Order matters.** A $0.00 string length check should run before a $0.02 LLM evaluation. If the output is obviously truncated, why waste tokens evaluating its content?

──────────────────────────────────────────────────

## Retry Patterns — Second Chances

### When to Retry
Many GenAI failures are transient. The same prompt can succeed on the second attempt because:
- Non-determinism means different sampling paths
- Truncation is often random, not systematic
- JSON formatting errors are inconsistent

### Retry Design Decisions

| Decision | Recommendation | Rationale |
|----------|---------------|-----------|
| Max retries | 2-3 | Diminishing returns beyond 3 |
| Feedback in retry | Include specific failure reason | "Your JSON was missing the 'verdict' field" |
| Backoff | Not needed (LLM calls, not rate limits) | Unless hitting rate limits |
| Fallback after max retries | Skip, escalate, or safe default | Never ship unvalidated output |

### Retry with Feedback
On retry, append the specific failure reason to the prompt:

**Original prompt:** "Analyse this data and return JSON..."

**Retry prompt:** "Analyse this data and return JSON... NOTE: Your previous response was missing the 'root_cause' field. Ensure all required fields are present."

This targeted feedback is dramatically more effective than blind retries.

──────────────────────────────────────────────────

## Evaluation Architecture Patterns

### Overview

| Pattern | Token Cost | Latency | Complexity | Best For |
|---------|-----------|---------|-----------|----------|
| 1. Single-Pass | 2× | Low | Low | Prototypes, POCs, baselines |
| 2. Iterative Refinement | 2-3× | Medium | Medium | Must-deliver, correctable errors |
| 3. Multi-Candidate | 3-4× | Low (parallel) | Medium | Quality-critical, high-variance |
| 4. Task Decomposition | Variable | High | High | Complex multi-part outputs, production |

Start with Pattern 1. Escalate based on evidence, not anxiety.

──────────────────────────────────────────────────

### Pattern 1: Generate → Evaluate (Single-Pass)

**How it works:** Generate an output, evaluate it once, ship or reject.

**Steps:**
1. Input data provided to Generator
2. Generator produces draft output
3. Evaluator scores/judges the draft
4. Filter: PASS → deliver, FAIL → discard or escalate

| Pros | Cons |
|---|---|
| Simple, lowest cost (2× tokens) | May miss nuanced errors |
| Fast to implement and iterate | Single evaluator has blind spots |
| Good baseline for measurement | Binary pass/fail may be too coarse |
| Easy to understand and debug | No self-correction mechanism |

**Best for:** Prototypes, POCs, simple outputs, establishing quality baselines.

**When to move on:** When logs show consistent failure patterns that a second pass could fix.

──────────────────────────────────────────────────

### Pattern 2: Iterative Refinement (Retry with Feedback)

**How it works:** Generate, evaluate, and if it fails, retry with specific feedback about what went wrong. Repeat up to N times.

**Steps:**
1. Input data provided to Generator
2. Generator produces draft output
3. Evaluator checks the draft
4. If FAIL: feed specific failure reason back to Generator, retry
5. If PASS: deliver
6. After max retries: fallback (skip, escalate, safe default)

| Pros | Cons |
|---|---|
| Higher success rate than single-pass | 2-3× token cost |
| Targeted improvement via feedback | Sequential latency (each retry adds time) |
| Ensures delivery for critical outputs | Poor feedback can reinforce errors |
| Self-correcting within limits | Diminishing returns after 2-3 retries |

**Best for:** Must-deliver scenarios where errors are correctable with guidance.

**When to move on:** When retries consistently fail on the same issues (the error isn't correctable with feedback).

──────────────────────────────────────────────────

### Pattern 3: Multi-Candidate with Arbiter

**How it works:** Generate multiple independent outputs, then use an arbiter to select the best one.

**Steps:**
1. Input data provided to multiple generators (A, B, C)
2. Each generator produces an independent draft
3. Arbiter receives all drafts
4. Arbiter selects the best candidate based on defined criteria
5. Deliver selected output

| Pros | Cons |
|---|---|
| Reduces variance (diversity of approaches) | 3-4× token cost |
| Parallel execution = low latency | All candidates may fail similarly |
| Picks best from diverse approaches | Arbiter logic is complex to design |
| Good for creative/subjective tasks | Wasted compute on rejected candidates |

**Best for:** Quality-critical outputs with high variance, creative tasks where "best" is subjective.

**When to move on:** When all candidates fail in similar ways (the problem is systematic, not variance).

──────────────────────────────────────────────────

### Pattern 4: Task Decomposition with Layered Validation

**How it works:** Break complex generation into discrete stages, each validated independently. Failed components are dropped early — no downstream compute wasted.

This is the most sophisticated pattern. It's production-grade.

**Stages:**
1. Pre-processing — calculate derived values once (avoid re-derivation drift)
2. Component Generation — generate structured components (batch)
3. Component Validation — validate each component against source data (batch)
4. Failed components → DROPPED (fail-fast)
5. Sub-item Generation — for each validated component, generate sub-items
6. Sub-item Validation — validate each sub-item independently
7. Reassembly — recompose validated items (deterministic, no LLM)
8. Quality Gate — cross-component consistency, conflict detection
9. Ranking — prioritise by severity/impact
10. Formatting — convert to output format (no content modification)
11. Format Validation — validate output structure and completeness
12. Deliver

| Pros | Cons |
|---|---|
| Granular validation at each layer | More complex orchestration |
| Different models per layer (cost efficient) | More failure points to handle |
| Pass data subsets only (token efficient) | Sequential latency adds up |
| Know exactly which component failed and why | Requires careful schema design |
| Fail-fast saves downstream compute | Reassembly logic must be deterministic |
| Cross-component checks (conflicts, duplicates) | Higher upfront development cost |

**Best for:** Complex multi-part outputs where components must validate independently, high-stakes production systems, outputs with many independently verifiable claims.

──────────────────────────────────────────────────

## Pattern 4 Deep Dive

### Core Design Principles

| Principle | Description |
|-----------|-------------|
| **Separation of Concerns** | Each stage does exactly one thing. Generators generate. Validators validate. Formatters format. |
| **Fail-Fast Economics** | If a component fails early, no compute is spent on its sub-items. 3 of 10 fail early → ~30% downstream savings. |
| **Independent Judgement** | Validators NEVER receive upstream CoT. They form their own conclusions from source data alone. No echo chambers. |
| **Full vs Subset Visibility** | Upstream stages see full dataset. Per-item stages see only relevant subset. Prevents cross-contamination. |

### Source of Truth Hierarchy
When a validator encounters conflicting information:

| Priority | Source | Treatment |
|----------|--------|-----------|
| 1 (highest) | Source data | Absolute truth |
| 2 | Traceability references | Must be verified against source data |
| 3 | Chain-of-thought | Evaluate for logical consistency (not a source of truth) |
| 4 (lowest) | Derived metrics | Reference only (may contain calculation errors) |

### Layer Design

| Layer | Model Tier | Data Scope | Purpose |
|---|---|---|---|
| Pre-processing | Reasoning | Full dataset | Complex calculations, derived values |
| Component Generator | Reasoning | Full dataset | Multi-source analysis, causal reasoning |
| Component Validator | Reasoning | Full dataset + components | LLM-as-Judge: verify each component against source |
| Sub-item Generator | Standard | Single component + context | Focused generation per component |
| Sub-item Validator | Standard | Single sub-item + source subset | Include/exclude decision per item |
| Quality Gate | Reasoning | All validated components | Cross-component conflict detection |
| Ranker | Standard | All passed components | Priority ordering |
| Formatter | Standard | Ranked output | Structure conversion |
| Format Validator | Standard | Formatted output | Structure and completeness checks |

**Model Selection Rationale:**
- **Reasoning models** (10× cost, 2-3× latency): Reserved for complex judgement, multi-source analysis, mathematical verification, semantic conflict detection
- **Standard models**: Focused single-item tasks, rule-guided generation, deterministic formatting, structural validation
- **No LLM**: Reassembly is deterministic (array filtering, object composition). Using an LLM here adds cost, latency, and non-determinism for zero benefit.

──────────────────────────────────────────────────

### Validation Layers in Depth

#### Layer 1 — Component Validation (LLM-as-Judge)

Validates every generated component against the full source data.

| Check | What It Verifies |
|-------|-----------------|
| Traceability | Every cited metric name and value exists in source data (within tolerance, e.g., ±2%) |
| Mathematics | Re-derives key calculations from source, compares against stated values |
| Category alignment | Variance magnitude matches the assigned severity category |
| Reasoning quality | Flags weak logic (doesn't fail if data is correct, but logs the concern) |
| Duplicate detection | If two components target the same metric and same concern, the later one fails |

Output appends `validation_result` (boolean) and `validation_reason` (string) directly to each component.

#### Layer 2 — Sub-Item Validation (Per-Item, Independent)

**Critical design choice:** The validator does NOT receive upstream chain-of-thought. It receives only:
- The component's headline, category, and domain
- The single sub-item to validate
- The traceability data subset
- Reference context (rules, site context)

| Validation Step | What It Checks |
|----------------|---------------|
| Action identification | What is the sub-item proposing? |
| Prerequisite check | Does the data support the preconditions for this action? |
| Data verification | Are all cited values accurate in the source data? |
| Metric evaluation | Do the numbers actually support the proposed action? |
| Problem alignment | Does the action address the problem stated in the headline? |

**Conservative by design:** When evidence is ambiguous, exclude rather than include. Better to show 3 provable items than 5 where 2 are assumptions.

#### Layer 3 — Quality Gate (Cross-Component)

Operates on the full batch of validated components:

| Check Category | What It Does |
|---------------|-------------|
| Structure completeness | Every component has required fields populated |
| Item count minimums | High-severity components need ≥N sub-items, low-severity need ≥1 |
| Format validation | No artefacts from previous stages |
| Cross-component consistency | No exact duplicate headlines across components |
| Cross-component conflict detection | If two components suggest opposite actions on the same resource, BOTH are failed |

**Conflict detection examples:**
- "Redeploy trucks to ex-pit" vs "Drop trucks off this run"
- "Extend shifts on drilling" vs "Reduce drilling to conserve"
- "Increase feed rate" vs "Reduce feed to clear blockage"

This is why the Quality Gate uses a Reasoning model — conflict detection requires understanding operational semantics, not just string matching.

#### Layer 4 — Ranking

Ranks all passed components by operational priority:

| Tier | Priority | Criteria |
|------|----------|---------|
| 1 (highest) | Safety-related | Always ranked first |
| 2 | High-severity | By variance magnitude |
| 3 | Moderate-severity | By variance magnitude |
| 4 | Advisory | By variance magnitude |
| 5 (lowest) | Resolved/positive | Original order |

Tie-breaking: prefer broader operational impact → prefer downstream process effects → original order.

──────────────────────────────────────────────────

### Fail-Fast Cascade

How failures propagate through the pipeline:

| Stage | Failure Behaviour |
|-------|------------------|
| Component Validation | Component dropped entirely. No sub-items generated for it. |
| Sub-item Validation | Individual sub-item excluded. Component survives if enough sub-items pass. |
| Quality Gate | Component dropped if too few sub-items remain (below minimum) or conflicts detected. |
| Format Validation | Output blocked. Delivery prevented. |
| All stages fail | No output delivered. Alert posted. Failure logged. |

**Key principle:** If it passes, it ships. If it doesn't, it's filtered out silently. Users never see confidence scores — the presence of an item in the output IS the confidence signal.

──────────────────────────────────────────────────

### Defence in Depth: Duplicate & Conflict Detection

Duplicates and conflicts are caught at multiple levels:

| Check | Where | Resolution |
|-------|-------|-----------|
| Duplicate generation prevention | Component Generator | Merge during generation |
| Duplicate detection | Component Validator | Fail the later component (higher ID) |
| Duplicate headlines | Quality Gate | Fail the duplicate |
| Cross-component conflicts | Quality Gate | Fail BOTH conflicting components |

Two components are duplicates if they reference the SAME primary metric AND the same concern. Same metric from different angles (e.g., daily vs week-to-date) should merge into one component. Different primary metrics = NOT duplicates even if one appears in the other's traceability.

──────────────────────────────────────────────────

### When to Use Pattern 4

| Use Pattern 4 When... | Don't Use Pattern 4 When... |
|---|---|
| Output has multiple independently verifiable components | Output is a single indivisible unit |
| Different components need different validation criteria | Latency budget is very tight |
| Cost optimisation matters (standard models for most layers) | Components can't be validated independently |
| You need to know exactly which component failed and why | Overhead of orchestration exceeds quality benefit |
| Cross-component consistency matters | A simpler pattern already achieves adequate quality |
| Domain has clear source of truth to validate against | |

**Evolution path:** Most implementations start with Pattern 1 and evolve when logs reveal specific failure classes:
- Random/inconsistent errors → Pattern 3 (multi-candidate) first
- Specific component types consistently fail → Pattern 4
- Correctable with feedback → Pattern 2 (iterative refinement)
- Pattern 4 + retries per layer is common in production

──────────────────────────────────────────────────

## Production Example: Daily Performance Insights (DPI)

The DPI pipeline is a production implementation of Pattern 4, generating daily mining operations email digests across 11 sites × 2 roles = 22 variants per day.

### Pipeline Stages

| # | Stage | Model | Execution | Purpose |
|---|---|---|---|---|
| 1 | Derived Metrics | Reasoning | Batch | Calculate composite metrics not in source (ratios, variances, efficiency indices) |
| 2 | Claim Generator | Reasoning | Batch | Analyse full dataset, generate structured insight claims with headlines, CoT, and traceability |
| 3 | Claim Validator | Reasoning | Batch | LLM-as-Judge: verify every claim's maths, traceability, and category against source |
| 4 | Suggestion Generator | Standard | Per-claim | Generate 3-6 actionable suggestions per validated claim |
| 5 | Suggestion Validator | Standard | Per-suggestion (parallel) | Validate each suggestion independently — no upstream CoT passed |
| 6 | Reassembly | None | Compose | Recompose claims with only validated suggestions |
| 7 | Quality Gate | Reasoning | Batch | Cross-claim conflict detection, structural checks, minimum suggestion counts |
| 8 | Reranker | Standard | Batch | Rank by safety → severity → variance magnitude |
| 9 | HTML Formatter | Standard | Batch | Convert to responsive HTML email |
| 10 | Format Validator | Standard | Batch | Validate HTML structure, sections, styling, content completeness |

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Claims vs Suggestions separated | Claims capture *what the data shows*; suggestions capture *what to do about it*. If a claim is wrong, no tokens wasted on suggestions. |
| Suggestion Validator receives no upstream CoT | Forms its own judgement from source data alone. Genuine second opinion, not an echo. |
| Quality Gate uses Reasoning model | Cross-claim conflict detection requires operational semantics understanding, not string matching. |
| Pre-processing calculates derived metrics | Without this, the Claim Generator would calculate inline, risking inconsistency across claims. |

### Observed Benefits

| Benefit | Impact |
|---------|--------|
| Fail-fast | ~30% downstream token cost saved when claims are rejected early |
| Per-suggestion validation | Catches 1-2 bad suggestions per digest that would otherwise ship |
| Cross-claim conflict detection | Prevents contradictory advice reaching operations teams |
| Granular logging | Pinpoints exactly which layer and component failed — "Layer 3 failed: math check 18% vs stated 22%" |

──────────────────────────────────────────────────

## Other Patterns Worth Knowing

| Pattern | Description | Best For |
|---------|-------------|----------|
| Ensemble Voting | Multiple evaluators vote on same output | When single evaluator isn't trusted |
| Hierarchical | Quick filter → detailed evaluation → expert review | Tiered quality requirements |
| A/B Testing | Run patterns in parallel, measure outcomes | Comparing approaches objectively |
| Cascading Models | Cheap model first, escalate to premium if needed | Cost-sensitive, variable complexity |
| Agentic Loops | Agent iterates with tool calls until task complete | Open-ended tasks |
| Multi-Agent Debate | Multiple agents argue, arbiter synthesises | Complex judgement calls |
| Reflection | Agent critiques own output, self-corrects before submission | Quality-sensitive, single-agent |
| Plan-then-Execute | Agent creates plan, validates, then executes | Multi-step reasoning tasks |

──────────────────────────────────────────────────

## Choosing Your Pattern — Decision Framework

### Step-by-Step

| Step | Action |
|------|--------|
| 1 | **Start simple** — use Pattern 1 for POC/prototype |
| 2 | **Establish baseline** — measure pass rates, failure modes, costs |
| 3 | **Analyse logs** — identify what's failing and why |
| 4 | **Escalate based on evidence** (see table below) |
| 5 | **Combine patterns** as needed (e.g., Pattern 4 + retries per layer) |

### Pattern Selection by Failure Type

| What Logs Reveal | Pattern to Try | Why |
|-----------------|---------------|-----|
| Random/inconsistent errors | Pattern 3 (multi-candidate) | Diversity reduces variance |
| Specific components consistently fail | Pattern 4 (decomposition) | Isolate and validate independently |
| Errors are correctable with feedback | Pattern 2 (iterative) | Targeted retry is cheaper than multi-candidate |
| Simple outputs, need a baseline | Pattern 1 (single-pass) | Minimum viable evaluation |
| All patterns still fail | Rethink the task decomposition or prompt design | The problem may be upstream |

──────────────────────────────────────────────────

## Observability & Logging

### Why It Matters

| Without Logging | With Logging |
|---|---|
| "It didn't work" | "Layer 2 failed: math check 18% vs stated 22%" |
| Guessing at patterns | "Pattern 1: 73% pass, Pattern 4: 94%" |
| Trial and error | "Prompt v1.2 reduced EXCLUDE rate 40% → 15%" |
| "I think it's better now" | "Pass rate improved 12% after last prompt change" |
| "Users are complaining" | "Layer 5 has 23% false negative rate on safety items" |

### What to Log

| Field | Source | Purpose |
|-------|--------|---------|
| Trace ID | `workflow()?['run']?['name']` | Link all stages of a single run |
| Stage/Layer | Hardcoded per stage | Know where failure occurred |
| Timestamp | `utcNow()` | Latency calculation |
| Input summary | Truncated input | Reproduce failures |
| Output/Verdict | Full output or verdict | What was decided |
| Chain-of-Thought | CoT from evaluator | Why it was decided |
| Model used | Model name/version | Correlate quality with model |
| Prompt version | Version tag | Correlate quality with prompt changes |
| Latency | Timestamp diff | Performance monitoring |
| Token count | API response metadata | Cost tracking |
| Retry count | Counter variable | Retry effectiveness |
| Final outcome | PASS/FAIL/SKIP | Aggregate success rates |

### Key Metrics to Track

| Metric | What It Tells You | Target |
|--------|------------------|--------|
| Pass Rate | Overall quality of generation | > 80% (depends on domain) |
| Layer Efficiency | Are early layers catching issues? | Most failures caught early |
| Retry Effectiveness | Are retries worth the cost? | > 50% of retries should succeed |
| False Positive Rate | What's slipping through? | < 5% |
| Cost per Approved Output | Efficiency | Trending down over time |
| Latency (P50, P95) | User experience | Within acceptable bounds |

### The Feedback Loop

| Phase | Action |
|-------|--------|
| Deploy | Release current version |
| Log | Capture structured data from every run |
| Analyse | Review failure patterns, pass rates, costs |
| Refine | Update prompts, thresholds, patterns |
| Redeploy | Release improved version |
| Repeat | Continuous improvement cycle |

**Review regularly:** failure patterns, pass rates per layer, user-reported errors, cost vs quality trends, retry effectiveness.

──────────────────────────────────────────────────

## Confidence & Filtering

### Creating Rubrics & Thresholds

| Step | Action | Example |
|------|--------|---------|
| 1 | Define 3-5 criteria | Data support, logic coherence, actionability |
| 2 | Choose scale | Binary, HIGH/MED/LOW, or numeric (0-100) |
| 3 | Write examples for each level | "Score 90: all metrics verified, clear logic..." |
| 4 | Set decision rules | PASS if score ≥ 70 AND no critical flags |
| 5 | Calibrate | Test against labelled examples, adjust thresholds |

### Filtering Strategies

| Strategy | How It Works | Best For |
|----------|-------------|----------|
| Binary gate (PASS/FAIL) | Hard threshold, no middle ground | High-stakes, no partial credit |
| Confidence threshold | Tunable quality bar (e.g., ≥ 70/100) | Adjustable quality vs volume trade-off |
| Ranked selection (Top N) | Score all, take the best N | Fixed output volume required |
| Tiered review | Auto-approve high, flag medium, reject low | Balancing automation with human oversight |

### Showing Confidence to Users

| Show Confidence When... | Hide Confidence When... |
|---|---|
| Partial evidence supports the output | Only high-confidence items ship |
| Users need to verify before acting | Scores would confuse non-technical users |
| Early rollout — building trust | Presence in output IS the confidence signal |
| Regulatory/compliance requires it | Numeric scores imply false precision |

──────────────────────────────────────────────────

## The Trust Equation

> **Trust = Rigorous Evaluation + Transparent Logging + Continuous Iteration**

### What You Can Prove

| Claim | Evidence |
|-------|---------|
| Outputs passed quality gates | Logged verdicts with CoT reasoning |
| Decisions are traceable | Every output links to inputs, reasoning, and validation |
| Failures are detected | Logged rejections with specific failure reasons |
| System improves over time | Pass rate trends, prompt version comparisons |
| Costs are controlled | Token usage, cost per output, credit consumption |

### What You Can't Prove
- That any individual output is "correct" (but you can prove it was validated)
- That the system will never fail (but you can prove failures are caught and logged)
- That the AI "understands" (but you can prove it follows defined rules consistently)

──────────────────────────────────────────────────

## Power Platform Implementation Notes

### AI Builder Tips

| Tip | Detail |
|-----|--------|
| Split complex tasks | Token limits are real — decompose |
| Always output JSON | Easier to parse, validate, and log |
| Premium models for reasoning | Standard for mechanical checks |
| Prompt for CoT in output | Native CoT extraction unsupported in AI Builder |

### Power Automate Tips

| Tip | Detail |
|-----|--------|
| Trace ID | `workflow()?['run']?['name']` |
| Try/Catch | Scopes + Configure Run After |
| Retries | Do Until with quality flags |
| Modularise | Child flows for reusability and timeouts |
| Timeout handling | Child flows have independent 30-min timeouts |

### Storage Options

| Data Type | Recommended Storage | Why |
|-----------|-------------------|-----|
| Structured logs | Dataverse | Queryable, relational |
| Large text (CoT, outputs) | SharePoint files | Reference path in Dataverse log row |
| Prompts & config | SharePoint with versioning | Version history, easy editing |
| Aggregated metrics | Dataverse or Excel | Reporting and dashboards |

### Known Limitations & Workarounds

| Limitation | Impact | Workaround |
|-----------|--------|-----------|
| Token limits per call | Can't process large documents in one call | Split into chunks, process sequentially |
| Dataverse 100KB row limit | Can't store large CoT/outputs in log rows | Store large text in SharePoint, reference path |
| 30-minute flow timeout | Long pipelines may timeout | Use child flows (each gets own timeout) |
| No built-in prompt versioning | Hard to track which prompt produced which output | SharePoint versioning + version tag in logs |
| No streaming | Can't show partial results | Use progress indicators / status messages |

──────────────────────────────────────────────────

## Key Takeaways

1. **You can't guarantee AI correctness** — but you can guarantee rigorous evaluation
2. **Separate generation from evaluation** — always, no exceptions
3. **Make reasoning visible** — Chain-of-Thought is your audit trail
4. **Start simple, escalate from evidence** — Pattern 1 → 2/3/4 based on what logs reveal
5. **Log everything that matters** — future you will be grateful
6. **Fail-fast saves money** — catch errors early, skip downstream waste
7. **Build observability first** — you can't improve what you can't measure
8. **Validators must be independent** — no echo chambers, no upstream CoT
9. **Iterate continuously** — deploy, log, analyse, refine, repeat
10. **The goal isn't perfect AI — it's provably validated AI**

> *Build observability first. Choose patterns from data. Make reasoning visible.*

──────────────────────────────────────────────────
END OF PRESENTATION
