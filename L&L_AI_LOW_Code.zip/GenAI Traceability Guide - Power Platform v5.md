# GenAI Traceability & Evaluation Guide
## Power Platform Implementation Guide — v5
──────────────────────────────────────────────────
## 1. The Problem
How can we be sure GenAI outputs are correct? We can't. Even with Chain-of-Thought visible, LLMs can hallucinate, misinterpret inputs, make flawed decisions, sandbag, or produce inconsistent outputs. This creates a trust problem for production systems.

Human-in-the-Loop doesn't scale — manual review is infeasible at volume, reviewers fatigue, and it defeats automation.

GenAI is inherently non-deterministic. The same prompt can produce different outputs. Common failures include truncated responses, malformed JSON, missing fields, and hallucinated data. Many resolve with a simple retry.

### The Alternative: Automated Evaluation + Observability
Since we cannot guarantee correctness, we focus on:
- Evaluation systems that catch errors before users see them
- Observability to diagnose failures post-hoc
- Explainability so decisions can be understood and audited
- Iteration based on what logs reveal

The goal: "Prove we validated rigorously and can trace why it was approved."

──────────────────────────────────────────────────
## 2. Core Principles
- **Traceable** — every output links to inputs and reasoning
- **Separate generation from evaluation** — generators optimise for fluency, not accuracy
- **Make reasoning visible** — use Chain-of-Thought (CoT) for evaluation and logging
- **Handle failure gracefully** — expect non-determinism and failure; use quality checks and retries
- **Log what matters** — enough to debug, iterate, and audit
- **Filter by confidence** — binary, scored, or ranked based on use case

──────────────────────────────────────────────────
## 3. Chain-of-Thought (CoT)
CoT forces the model to reason step-by-step, making decisions auditable. Use it for evaluation and logging.

> Note: AI Builder doesn't support extracting native CoT from reasoning models. Prompt the model to return reasoning in JSON output.

Why CoT matters:
- Exposes reasoning flaws a direct answer would hide
- Creates audit trail for approvals/rejections
- Improves accuracy — models perform better when they reason first

Example prompt approach:
```
Evaluate this [item] against the source data.

Think through:
- What claim is being made?
- What evidence would support it?
- Is that evidence present?
- Does it support or contradict the claim?

Return JSON with your reasoning and verdict.
```

Example output schema:
```json
{
  "chain_of_thought": "The suggestion assumes truck capacity is available. Source shows utilization at 92%, no spare capacity. Not viable.",
  "verdict": "EXCLUDE",
  "reason": "Truck utilization too high"
}
```

Log CoT for:
- Validation decisions (why included/excluded)
- Ranking decisions (why prioritised)
- Quality gate failures (what specifically failed)

This enables debugging ("Why did the validator exclude this?"), prompt improvement, and audit trails.

──────────────────────────────────────────────────
## 4. Handling Failures & Retries

### Common Failure Modes

| Failure | Detection |
|---|---|
| Truncated output | Length below threshold |
| Missing fields | Schema validation |
| Malformed JSON | Parse error |
| Wrong format | Format validation |
| Hallucinated data | Cross-reference source |

### Quality Flags
Run deterministic checks before expensive semantic evaluation:
- Output length above minimum?
- Required JSON keys present?
- Data types correct?
- Cited values exist in source?

### Retry Patterns
**Do Until loops:**
```
Do Until: quality_pass = true OR retry_count >= 3
  ├─ Call AI Builder
  ├─ Quality checks (length, schema, format)
  ├─ If FAIL: increment retry_count, add failure feedback to prompt
  └─ If PASS: exit loop
```

**Try/Catch with Scopes:** Wrap AI Builder calls in Scopes for fault isolation. Use Configure Run After to handle failures gracefully.

Design decisions:
- Max retries: 2–3 (diminishing returns beyond)
- Feedback: Include specific failure reason in retry prompt
- Fallback: Skip, escalate, or safe default after max retries

──────────────────────────────────────────────────
## 5. Evaluation Architecture Patterns
Explore and combine patterns based on your needs. These are thought-starters.

### Pattern 1: Generate → Evaluate (Single-Pass)

```
Input → Generator → Draft → Evaluator → Score/Verdict → Filter → Deliver
```

| Pros | Cons |
|---|---|
| Simple, lowest cost (2× tokens) | May miss nuanced errors |
| Fast iteration | Single evaluator has blind spots |
| Good baseline for measurement | May be simplistic for production |

Best for: Prototypes, POCs, simple outputs, establishing baselines.

──────────────────────────────────────────────────
### Pattern 2: Iterative Refinement (Retry with Feedback)

```
Input → Generator → Draft → Evaluator → FAIL? → Feedback → Retry (max N)
                                  ↓
                                PASS → Deliver
```

| Pros | Cons |
|---|---|
| Higher success rate | 2–3× token cost |
| Targeted improvement | Sequential latency |
| Ensures delivery | Poor feedback reinforces errors |

Best for: Must-deliver scenarios where errors are correctable.

──────────────────────────────────────────────────
### Pattern 3: Multi-Candidate with Arbiter

```
Input ─┬─→ Generator A ──┐
       ├─→ Generator B ──┼─→ Arbiter → Select Best → Deliver
       └─→ Generator C ──┘
```

| Pros | Cons |
|---|---|
| Reduces variance | 3–4× token cost |
| Parallel = low latency | All candidates may fail similarly |
| Picks best from diverse approaches | Arbiter logic is complex |

Best for: Quality-critical, high-variance outputs.

──────────────────────────────────────────────────
### Pattern 4: Task Decomposition with Layered Validation

This is the most sophisticated pattern. It breaks complex generation into discrete stages, each validated independently before the next stage begins. Failed components are dropped early — no downstream compute is wasted on them.

#### 4.1 Architecture Overview

```
Input Data
    │
    ▼
┌──────────────────┐
│ Pre-processing   │  Calculate derived values once (avoid re-derivation drift)
└────────┬─────────┘
         ▼
┌──────────────────┐
│ Component Gen    │  Generate structured components (batch)
└────────┬─────────┘
         ▼
┌──────────────────┐
│ Component        │  Validate each component against source data (batch)
│ Validator + CoT  │  Failed components → DROPPED (fail-fast)
└────────┬─────────┘
         ▼
   ┌─────┴─────┐
   │ Per-Item   │  For each validated component:
   │ Loop       │    ├─ Generate sub-items (per-component, Standard model)
   │            │    └─ Validate each sub-item independently (per-item, Standard model)
   └─────┬─────┘
         ▼
┌──────────────────┐
│ Reassembly       │  Recompose validated items (deterministic — no LLM)
└────────┬─────────┘
         ▼
┌──────────────────┐
│ Quality Gate     │  Cross-component consistency, conflict detection, structural checks
└────────┬─────────┘
         ▼
┌──────────────────┐
│ Ranker           │  Prioritise by severity/impact → Top N
└────────┬─────────┘
         ▼
┌──────────────────┐
│ Formatter        │  Convert to output format (no content modification)
└────────┬─────────┘
         ▼
┌──────────────────┐
│ Format Validator │  Validate output structure and completeness
└────────┬─────────┘
         ▼
      Deliver
```

| Pros | Cons |
|---|---|
| Granular validation | More complex orchestration |
| Different models per layer (cost efficient) | More failure points to handle |
| Pass data subsets only (token efficient) | Sequential latency |
| Know exactly which component failed | Requires careful schema design between stages |
| Fail-fast saves downstream compute | Reassembly logic must be deterministic |

Best for: Complex multi-part outputs where components must validate independently, high-stakes production systems, outputs with many independently verifiable claims.

#### 4.2 Core Design Principles

**Separation of Concerns**
Each stage does exactly one thing. Generators generate. Validators validate. Formatters format. No stage modifies content that another stage is responsible for.

**Fail-Fast Economics**
If a component fails validation at Stage 3, no compute is spent generating or validating sub-items for it. In a pipeline producing 10 components where 3 fail early, this saves ~30% of downstream token cost.

**Independent Judgement**
Validators must form their own conclusions. A sub-item validator should NOT receive the generator's chain-of-thought or reasoning. If it does, it will be biased toward agreeing. Make validators self-contained — they receive only the item to validate, the source data, and the rules. This ensures a genuine second opinion, not an echo chamber.

**Full vs Subset Visibility**
- Upstream stages (component generation, component validation, quality gate) see the **full dataset**
- Per-item stages (sub-item generation, sub-item validation) see only the **relevant data subset** for their item
- This prevents cross-contamination and keeps per-item calls focused and token-efficient

**Source of Truth Hierarchy**
When a validator encounters conflicting information:
1. **Source data** = absolute truth
2. **Traceability** = must be verified against source data
3. **Chain-of-thought** = evaluate for logical consistency (not a source of truth)
4. **Derived metrics** = reference only (may contain calculation errors)

#### 4.3 Layer Design

| Layer | Model Tier | Data Scope | Purpose |
|---|---|---|---|
| Pre-processing | Reasoning | Full dataset | Complex calculations, derived values |
| Component Generator | Reasoning | Full dataset | Multi-source analysis, causal reasoning |
| Component Validator | Reasoning | Full dataset + components | LLM-as-Judge: verify each component against source |
| Sub-item Generator | Standard | Single component + context | Focused creative generation per component |
| Sub-item Validator | Standard | Single sub-item + source subset | Include/exclude decision per item |
| Quality Gate | Reasoning | All validated components | Cross-component conflict detection |
| Ranker | Standard | All passed components | Priority ordering by severity/impact |
| Formatter | Standard | Ranked output | Deterministic structure conversion |
| Format Validator | Standard | Formatted output | Structure and completeness checks |

**Model Selection Rationale:**
- **Reasoning models** (10× cost, 2–3× latency): Reserved for stages requiring complex judgement, multi-source analysis, mathematical verification, or semantic conflict detection.
- **Standard models**: Used for focused single-item tasks, rule-guided generation, deterministic formatting, and structural validation.
- **No LLM**: Reassembly/recomposition is deterministic (array filtering, object composition). Using an LLM here would add cost, latency, and non-determinism for zero benefit.

#### 4.4 Validation Layers in Depth

Pattern 4's power comes from layered validation — multiple independent checkpoints, each catching different classes of error.

**Layer 1 — Component Validation (LLM-as-Judge)**
Validates every generated component against the full source data. Checks:
- Traceability: every cited metric name and value exists in source data (within tolerance, e.g., ±2%)
- Mathematics: re-derives key calculations from source, compares against stated values
- Category/threshold alignment: variance magnitude matches the assigned severity category
- Reasoning quality: flags weak logic (doesn't fail if data is correct, but logs the concern)
- Duplicate detection: if two components target the same metric and same concern, the later one is failed

Output appends `validation_result` (boolean) and `validation_reason` (string) directly to each component — keeping schemas flat for Power Automate filtering.

**Layer 2 — Sub-Item Validation (Per-Item, Independent)**
Validates each sub-item in isolation. Critical design choice: the validator does NOT receive upstream chain-of-thought. It receives only:
- The component's headline, category, and domain
- The single sub-item to validate
- The traceability data subset
- Reference context (rules, site context)

Validation process:
1. **Action identification** — what is the sub-item proposing?
2. **Prerequisite check** — does the data support the preconditions for this action?
3. **Data verification** — are all cited values accurate in the source data?
4. **Metric evaluation** — do the numbers actually support the proposed action?
5. **Problem alignment** — does the action address the problem stated in the headline?

Conservative by design: when evidence is ambiguous, exclude rather than include. Better to show 3 provable items than 5 where 2 are assumptions.

**Layer 3 — Quality Gate (Cross-Component)**
Operates on the full batch of validated components. Performs five check categories:
1. **Structure completeness** — every component has required fields populated
2. **Item count minimums** — high-severity components need ≥N sub-items, low-severity need ≥1
3. **Format validation** — no artefacts from previous stages, sufficient data references
4. **Cross-component consistency** — no exact duplicate headlines across components
5. **Cross-component conflict detection** — if two components suggest opposite actions on the same resource, **both** are failed

Conflict detection examples:
- "Redeploy trucks to ex-pit" vs "Drop trucks off this run"
- "Extend shifts on drilling" vs "Reduce drilling to conserve"
- "Increase feed rate" vs "Reduce feed to clear blockage"

This is why the Quality Gate uses a Reasoning model — conflict detection requires understanding operational semantics, not just string matching.

**Layer 4 — Ranking**
Ranks all passed components by operational priority. Tiered approach:
1. Safety-related (always highest)
2. High-severity by variance magnitude
3. Moderate-severity by variance magnitude
4. Advisory by variance magnitude
5. Resolved/positive in original order

Tie-breaking: prefer broader operational impact → prefer downstream process effects → original order.

#### 4.5 Reassembly: The Deterministic Join Point

After per-item loops complete, the validated results must be recomposed into a batch. This is a **deterministic operation** (no LLM) — typically a Compose action + array variable in Power Automate:

1. For each component, filter sub-items where validation passed
2. Rebuild component object with only validated sub-items
3. Collect all rebuilt components into a batch array
4. Pass batch forward to Quality Gate

This is the critical schema transformation point. If your upstream loops output flat arrays and your downstream stages expect nested objects, this is where the mapping happens. Test this step rigorously — schema mismatches here silently corrupt downstream stages.

#### 4.6 Fail-Fast Cascade

How failures propagate through the pipeline:

```
Stage          │ Failure Behaviour
───────────────┼──────────────────────────────────────────────────
Component Val  │ Component dropped entirely. No sub-items generated.
Sub-item Val   │ Individual sub-item excluded. Component survives
               │   if enough sub-items pass.
Quality Gate   │ Component dropped. If too few sub-items remain
               │   (below minimum), component fails here.
Format Val     │ Output blocked. Delivery prevented.
All fail       │ No output delivered. Alert posted. Log failure.
```

Key principle: **if it passes, it ships. If it doesn't, it's filtered out silently.** Users never see confidence scores — the presence of an item in the output IS the confidence signal.

#### 4.7 Execution Topology

Not all stages run the same way:

| Stage Type | Execution | Why |
|---|---|---|
| Pre-processing | Single batch call | One calculation pass over full data |
| Component Gen | Single batch call | Full dataset context needed |
| Component Val | Single batch call | Cross-component duplicate detection |
| Sub-item Gen | Per-component loop | Each component has different context |
| Sub-item Val | Per-sub-item (parallel within component) | No dependencies between sub-items |
| Reassembly | Deterministic (no LLM) | Array filtering and recomposition |
| Quality Gate | Single batch call | Cross-component conflict detection |
| Ranker | Single batch call | Relative ordering requires full set |
| Formatter | Single batch call | All components formatted together |
| Format Val | Single batch call | Validates complete output |

Sub-item validation calls within a single component can run **in parallel** — each writes to its own output with no race conditions.

#### 4.8 Defence in Depth: Duplicate & Conflict Detection

Duplicates and conflicts are caught at **multiple levels** — not just one gate:

| Check | Where | Resolution |
|---|---|---|
| Duplicate generation prevention | Component Generator | Merge during generation |
| Duplicate detection | Component Validator | Fail the later component (higher ID) |
| Duplicate headlines | Quality Gate | Fail the duplicate |
| Cross-component conflicts | Quality Gate | Fail **both** conflicting components |

Two components are duplicates if they reference the SAME primary metric AND the same concern. Same metric from different angles (e.g., daily vs week-to-date) → merge into one component. Different primary metrics = NOT duplicates even if one appears in the other's traceability.

#### 4.9 When to Use Pattern 4

**Use Pattern 4 when:**
- Output has multiple independently verifiable components
- Different components need different validation criteria
- Cost optimisation matters (standard models for most layers)
- You need to know exactly which component failed and why
- Cross-component consistency matters (conflicts, duplicates)
- The domain has a clear source of truth to validate against

**Don't use Pattern 4 when:**
- Output is a single indivisible unit (use Pattern 1 or 2)
- Latency budget is very tight (sequential stages add up)
- Components can't be validated independently
- The overhead of orchestration exceeds the quality benefit

**Evolving to Pattern 4:**
Most implementations start with Pattern 1 (single-pass) and evolve when logs reveal specific failure classes that decomposition addresses:
- Random/inconsistent errors → consider Pattern 3 (multi-candidate) first
- Specific component types consistently fail → Pattern 4
- Correctable with feedback → Pattern 2 (iterative refinement)
- Pattern 4 + retries per layer is common in production

#### 4.10 Implementation Example: Daily Performance Insights

The DPI pipeline is a production implementation of Pattern 4, generating daily mining operations email digests across 11 sites × 2 roles = 22 variants per day.

**Pipeline stages:**

| # | Stage | Model | Execution | Purpose |
|---|---|---|---|---|
| 1 | Derived Metrics | Reasoning | Batch | Calculate composite metrics from raw data — ratios, variances, efficiency indices not in source |
| 2 | Claim Generator | Reasoning | Batch | Analyse full dataset, generate structured insight claims with headlines, CoT, and traceability |
| 3 | Claim Validator | Reasoning | Batch | LLM-as-Judge: verify every claim's maths, traceability, and category against source data |
| 4 | Suggestion Generator | Standard | Per-claim | Generate 3–6 actionable suggestions per validated claim |
| 5 | Suggestion Validator | Standard | Per-suggestion (parallel) | Validate each suggestion independently — no upstream CoT passed |
| 6 | Reassembly | None (deterministic) | Compose | Recompose claims with only validated suggestions |
| 7 | Quality Gate | Reasoning | Batch | Cross-claim conflict detection, structural checks, minimum suggestion counts |
| 8 | Reranker | Standard | Batch | Rank by safety → severity → variance magnitude |
| 9 | HTML Formatter | Standard | Batch | Convert to responsive HTML email — formatting only, no content modification |
| 10 | Format Validator | Standard | Batch | Validate HTML structure, sections, styling, content completeness |

**Key design decisions:**
- **Claims vs Suggestions separated** — claims capture *what the data shows*, suggestions capture *what to do about it*. If a claim is wrong, tokens are never wasted generating suggestions for it.
- **Suggestion Validator receives no upstream CoT** — forms its own judgement from source data alone. A genuine second opinion, not an echo.
- **Quality Gate uses Reasoning model** despite mostly structural checks — cross-claim conflict detection requires operational semantics understanding.
- **Format Validator is an LLM doing deterministic work** — known tech debt. Kept for now as it's low cost and catches edge cases a regex might miss.
- **Pre-processing (Derived Metrics)** — calculates composite values once upfront. Without this, the Claim Generator would calculate them inline, risking inconsistency across claims.

**Observed benefits:**
- Fail-fast saves ~30% of downstream token cost when claims are rejected early
- Per-suggestion validation catches 1–2 bad suggestions per digest that would otherwise ship
- Cross-claim conflict detection prevents contradictory advice reaching operations teams
- Logs pinpoint exactly which layer and which component failed — "Layer 3 failed: math check 18% vs stated 22%"

──────────────────────────────────────────────────
### Other Patterns
- **Ensemble voting:** Multiple evaluators vote on same output
- **Hierarchical:** Quick filter → detailed evaluation → expert review
- **A/B testing:** Run patterns in parallel, measure outcomes
- **Cascading models:** Cheap model first, escalate to premium if needed
- **Agentic loops:** Agent iterates with tool calls until task complete
- **Multi-agent debate:** Multiple agents argue, arbiter synthesises
- **Reflection:** Agent critiques own output, self-corrects before submission
- **Plan-then-execute:** Agent creates plan, validates, then executes

──────────────────────────────────────────────────
### Decision Framework
1. **Start simple** — use a basic pattern (like Pattern 1) for POC/prototype
2. **Establish baseline** — measure pass rates, failure modes, costs
3. **Analyse logs and evals** — identify what's failing and why
4. **Iterate to complexity** based on evidence:
   - Random/inconsistent errors → Pattern 3 (multi-candidate)
   - Specific component fails → Pattern 4 (decomposition)
   - Correctable with feedback → Pattern 2 (iterative)
5. **Combine patterns** as needed (e.g., Pattern 4 + retries per layer)

──────────────────────────────────────────────────
## 6. Observability & Logging

### Why It Matters
Without logging, debugging is guesswork. With structured logging, you can trace exactly where and why failures occur, track quality over time, and make data-driven prompt improvements.

| Without Logging | With Logging |
|---|---|
| "It didn't work" | "Layer 2 failed: math check 18% vs stated 22%" |
| Guessing patterns | "Pattern 1: 73% pass, Pattern 4: 94%" |
| Trial and error | "Prompt v1.2 reduced EXCLUDE rate 40%→15%" |

### What to Log
Design schema based on observability needs. Consider:
- **Trace ID:** `workflow()?['run']?['name']`
- Stage/layer, timestamp
- Input summary, output/verdict
- Chain-of-thought reasoning
- Model, prompt version
- Latency, token count, retry count
- Aggregates: stages passed/failed, final outcome, total cost

### Key Metrics

| Metric | Why |
|---|---|
| Pass Rate | Overall quality |
| Layer Efficiency | Early layers catching issues? |
| Retry Effectiveness | Retries worth the cost? |
| False Positive Rate | What's slipping through? |
| Cost per Approved Output | Efficiency |

### Feedback Loop
```
Deploy → Logs → Analyse Failures → Refine → Redeploy
```

Regularly review: failure patterns, pass rates per layer, user-reported errors, cost vs quality, retry effectiveness.

──────────────────────────────────────────────────
## 7. Confidence & Filtering

### Creating Rubrics & Thresholds
1. Define 3–5 criteria — e.g., data support, logic coherence, actionability
2. Choose scale — binary, HIGH/MED/LOW, or numeric (0–100)
3. Write examples for each level to anchor evaluators
4. Set decision rules — e.g., PASS if score ≥70 AND no critical flags
5. Calibrate — test against labelled examples, adjust thresholds

### Filtering Strategies

| Strategy | When |
|---|---|
| Binary gate (PASS/FAIL) | High-stakes, no partial credit |
| Confidence threshold | Tunable quality bar |
| Ranked selection (top N) | Fixed output volume |
| Tiered review | Route edge cases to secondary evaluation |

### Showing Confidence to Users
- **Show when:** Partial evidence, users need to verify, early rollout trust-building.
- **Hide when:** Only high-confidence ships (presence = confidence), scores confuse users.

### Trust Equation
> Trust = Rigorous Evaluation + Transparent Logging + Continuous Iteration

You can prove: outputs passed gates, decisions are logged, failures are addressed, system improves.

──────────────────────────────────────────────────
## 8. Power Platform Notes

### AI Builder
- Split complex tasks (token limits)
- Always output JSON — easier to parse, validate, and log
- Premium models for reasoning, standard for mechanical checks
- Prompt for CoT in output (native extraction unsupported)

### Power Automate
- **Trace ID:** `workflow()?['run']?['name']`
- **Try/Catch:** Scopes + Configure Run After
- **Retries:** Do Until with quality flags
- **Modularise:** Child flows for reusability and timeouts

### Storage

| Data | Options |
|---|---|
| Logs | Dataverse |
| Large text (CoT, outputs) | SharePoint files (reference path in log) |
| Prompts & Config | SharePoint with versioning |

### Limitations

| Issue | Workaround |
|---|---|
| Token limits | Split calls |
| Dataverse 100KB row | Large text → SharePoint |
| 30min timeout | Child flows |
| No prompt versioning | SharePoint versioning |

──────────────────────────────────────────────────
## 9. Dynamic Inputs: Files & Lists
Avoid hardcoding prompts and config. Use external sources for flexibility.

### Pattern: SharePoint-Driven Prompts
```
Get File Content (SharePoint) → System Prompt
Get File Content (SharePoint) → Rules/Context
Compose → Combine into full prompt
AI Builder → Generate
```

Benefits: Version history, easy updates without flow changes, A/B testing by swapping files.

### Pattern: Config Lists
Store thresholds, feature flags, and variant configs in SharePoint lists or Dataverse:
- Enable/disable features per site or role
- Adjust thresholds without redeployment
- Query at runtime, cache if needed

──────────────────────────────────────────────────
## 10. Copilot Studio: Agentic Patterns
Copilot Studio enables conversational agents with tool orchestration.

### Generator + Evaluator Loop
```
User Query → Topic: Generate
  ↓
Action: Call Generator Flow → Returns draft
  ↓
Action: Call Evaluator Flow → Returns verdict
  ↓
Condition: PASS? → Display / Retry with feedback (max 2)
```

### Multi-Step Agent
```
User Query → Copilot parses intent
  ↓
Action 1: Get data (Power Automate / Dataverse)
  ↓
Action 2: Analyse (AI Builder)
  ↓
Action 3: Validate (AI Builder)
  ↓
Adaptive Card: Display result with source link
```

### Tool Orchestration
Copilot can call multiple actions (flows, connectors) based on context:
- **Retrieval:** Fetch relevant data before generation
- **Validation:** Call separate validator after generation
- **Logging:** Log conversation turns to Dataverse

Key: Each action returns structured JSON. Copilot variables pass data between steps.

──────────────────────────────────────────────────
## 11. Summary
- GenAI is non-deterministic — handle failures gracefully with quality checks and retries
- Use CoT for evaluation AND logging — makes reasoning auditable
- Start simple (Pattern 1), escalate based on log evidence
- Each pattern has trade-offs — choose by quality, cost, latency needs
- **Pattern 4 is the production-grade choice** for complex multi-part outputs — invest in orchestration, gain granular validation and cost efficiency
- Log what matters — CoT, verdicts, retries, costs
- Filter by use case — binary, scored, ranked, or tiered
- Iterate — use logs to diagnose and improve

> Build observability first. Choose patterns from data. Make reasoning visible.

──────────────────────────────────────────────────
END OF GUIDE
