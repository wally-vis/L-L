# AI in the Power Platform: AI Builder & Copilot Studio

## A Practical Guide to Getting Started

──────────────────────────────────────────────────

## Slide 1 — Title

**AI in the Power Platform**
AI Builder, Custom Prompts & Copilot Studio — A Practical Guide

*No PhD required. No robots taking your job (today).*

Audience: Everyone — whether you've built 50 Power Automate flows or you're still figuring out what a "trigger" is.

──────────────────────────────────────────────────

## Slide 2 — What Are We Covering?

This session is your on-ramp to using AI features across the Power Platform:

| Platform | What You'll Learn |
|---|---|
| **Power Automate** | AI Hub, Custom Prompts, invoking LLMs in flows |
| **Power Apps** | Where AI Builder fits into app experiences |
| **Copilot Studio** | Building AI agents, when to use it vs Power Automate |

What We're NOT Doing:
❌ Building a sentient chatbot
❌ Replacing your team with AI
❌ Promising it works first try every time

What We ARE Doing:
✅ Showing you where the AI features live
✅ Walking through real examples
✅ Giving you patterns to build reliably
✅ Being honest about what breaks and how to handle it

──────────────────────────────────────────────────

## Slide 3 — Power Automate: The AI Hub

When you open Power Automate, navigate to **AI Hub** — this is your launchpad.

You'll find a buffet of AI capabilities:

**Pre-built Models (Ready to Go):**
- 📄 Document Processing — extract data from invoices, receipts, forms
- 🔍 Text Recognition (OCR) — pull text from images and scanned docs
- 💳 Business Card Reader — because manually typing contact info is so 2015
- 📊 Sentiment Analysis — find out how angry that email really is
- 📝 Entity Extraction — pull out names, dates, locations from text

**These are useful, but the real power is...**

──────────────────────────────────────────────────

## Slide 4 — Custom Prompts: The Game Changer

**Custom Prompts** let you invoke an LLM directly inside your Power Automate flow.

This is where it gets interesting. You're essentially calling GPT (or other models) as a step in your automation — feed it data, get back structured results, and keep the flow going.

Think of it as:
> "Hey AI, here's some data. Analyse it, structure your response as JSON, and hand it back so the next step in my flow can use it."

**Why this matters:**
- You can build AI-powered automations without writing code
- The LLM becomes just another action in your flow
- You control the prompt, the inputs, the output format, and the model

──────────────────────────────────────────────────

## Slide 5 — Dynamic Prompts: The Real Power Move

Most people hardcode their prompts in AI Builder. That works — but it's limiting. The real power is making your **entire prompt dynamic**.

### The Concept

Instead of writing a fixed prompt in AI Builder with a few input variables, you flip the approach:
- The AI Builder Custom Prompt is essentially an **empty shell** — just variable placeholders
- **All** the prompt content is assembled and injected from the Power Automate flow at runtime
- The system prompt, instructions, rules, examples — **everything** is a variable

> Think of the AI Builder action as a dumb pipe. The intelligence is in how you assemble the prompt *before* it gets there.

### Why This Matters
- 🔀 **Conditional logic** — different prompts for different scenarios without duplicating AI Builder actions
- 📝 **Centralised prompt management** — update prompts in SharePoint/Dataverse, not inside individual flows
- 🧪 **A/B testing** — swap prompt versions without editing the flow
- 🔄 **Reusability** — one AI Builder Custom Prompt action serves dozens of different use cases

──────────────────────────────────────────────────

## Slide 6 — Dynamic Prompts: How It Works

### Step 1: Set Up Your Custom Prompt as a Shell

In AI Builder, create a Custom Prompt where **every component is a variable**:

```
┌─────────────────────────────────────────────┐
│  AI Builder Custom Prompt                   │
│                                             │
│  System Prompt:   {{SystemPrompt}}          │
│  Instructions:    {{Instructions}}          │
│  Rules:           {{Rules}}                 │
│  Examples:        {{Examples}}              │
│  Input Data:      {{InputData}}             │
│  Output Schema:   {{OutputSchema}}          │
│                                             │
│  (No hardcoded text — it's ALL variables)   │
└─────────────────────────────────────────────┘
```

### Step 2: Assemble the Prompt in Power Automate

In your flow, **before** the AI Builder step, gather and compose each component:

```
┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│  SharePoint List │     │  Dataverse Table │     │  Text File       │
│  "Prompt Rules"  │     │  "System Prompts"│     │  "examples.json" │
└────────┬─────────┘     └────────┬─────────┘     └────────┬─────────┘
         │                        │                         │
         ▼                        ▼                         ▼
┌────────────────────────────────────────────────────────────────────┐
│                    Compose / Build Variables                       │
│                                                                    │
│  SystemPrompt  ← Dataverse query (filtered by report type)        │
│  Instructions  ← SharePoint item (based on site/department)       │
│  Rules         ← SharePoint list (filtered by category)           │
│  Examples      ← Text file or Dataverse (versioned examples)      │
│  InputData     ← Previous flow step (email, report, form data)    │
│  OutputSchema  ← Dataverse (schema registry)                      │
└────────────────────────────┬───────────────────────────────────────┘
                             │
                             ▼
                 ┌───────────────────────┐
                 │  AI Builder Action    │
                 │  (Custom Prompt)      │
                 │  All variables fed in │
                 └───────────────────────┘
```

### Step 3: Conditional Assembly

The power comes from the flow logic *before* the AI Builder step:

- **Condition:** If report type = "Safety" → pull safety-specific rules & examples
- **Condition:** If site = "Pilbara" → add site-specific context to system prompt
- **Condition:** If language = "Spanish" → swap in Spanish instructions
- **Switch:** Based on department → load department-specific output schema

The AI Builder action never changes. The prompt it receives changes every time.

──────────────────────────────────────────────────

## Slide 7 — Dynamic Prompts: Example

**Scenario:** One flow handles performance reports for multiple departments, each with different analysis criteria.

```
Trigger: Scheduled (daily)
    │
    ├─► Get report data from Power BI
    │
    ├─► Get department from report metadata
    │
    ├─► Switch on Department:
    │       │
    │       ├─ "Mining Ops"
    │       │    ├─► Query SharePoint: Get mining rules list
    │       │    ├─► Query Dataverse: Get mining system prompt
    │       │    └─► Query Dataverse: Get mining examples
    │       │
    │       ├─ "Processing"
    │       │    ├─► Query SharePoint: Get processing rules list
    │       │    ├─► Query Dataverse: Get processing system prompt
    │       │    └─► Query Dataverse: Get processing examples
    │       │
    │       └─ "Logistics"
    │            ├─► Query SharePoint: Get logistics rules list
    │            ├─► Query Dataverse: Get logistics system prompt
    │            └─► Query Dataverse: Get logistics examples
    │
    ├─► Compose: Assemble full prompt from components
    │
    ├─► AI Builder Custom Prompt (single action, dynamic input)
    │
    ├─► Validate Output (JSON check, quality gates)
    │
    └─► Route results to department stakeholders
```

**One flow. One AI Builder action. Multiple departments. Fully dynamic.**

### Where to Store Your Prompt Components

| Component | Recommended Source | Why |
|---|---|---|
| System Prompt | Dataverse / SharePoint list | Versioned, editable by non-devs |
| Rules | SharePoint list (one rule per row) | Easy to add/remove/reorder rules |
| Examples | Dataverse or JSON text file | Structured, versionable |
| Output Schema | Dataverse | Central schema registry |
| Instructions | SharePoint / Dataverse | Vary by use case, easily updated |

*[Screenshots of AI Builder prompt editor with variable placeholders will go here]*

──────────────────────────────────────────────────

## Slide 8 — Picking the Right Model

AI Builder gives you model choices. Pick based on your use case:

### Standard Models (Lower Cost)
| Model | Best For | Trade-off |
|---|---|---|
| GPT-4.1-mini | Simple classification, summarisation, short text tasks | Faster & cheaper, but struggles with complex reasoning |
| GPT-4.1-nano | Very simple tasks, yes/no, short extraction | Cheapest option, limited capability |

### Premium Models (Higher Cost, Higher Capability)
| Model | Best For | Trade-off |
|---|---|---|
| GPT-4.1 | General-purpose analysis, long documents, structured output | Good balance of cost vs capability |
| o3 / GPT-5 Reasoning | Complex multi-step reasoning, nuanced analysis | Significantly more expensive, but much smarter |
| GPT-5 Chat | Latest flagship, strong all-rounder | New — evaluate for your use case |

**Rule of Thumb:**
- Start with the cheapest model that works → only upgrade if quality isn't good enough
- Don't use a reasoning model to summarise an email — that's like hiring a brain surgeon to put on a Band-Aid

──────────────────────────────────────────────────

## Slide 9 — Cost: The Uncomfortable Slide

⚠️ **AI Builder is 3–40x more expensive than direct Azure OpenAI**

| Model | Usage | Azure OpenAI (US$/1M tokens) | AI Builder (US$/1M tokens) | Markup |
|---|---|---|---|---|
| GPT-4.1 | Input | $2.00 | $10.00 | **5x** |
| GPT-4.1 | Output | $8.00 | $30.00 | **3.75x** |
| o3 | Input | $2.00 | $80.00 | **40x** |
| o3 | Output | $8.00 | $320.00 | **40x** |
| GPT-5 Chat | Input | $1.25 | $10.00 | **8x** |
| GPT-5 Chat | Output | $10.00 | $30.00 | **3x** |

**What you're paying for:** Convenience, low-code integration, managed infrastructure, and Microsoft's margin.

**When it's worth it:** Prototyping, low-volume workflows, teams without dev resources.
**When it's NOT worth it:** High-volume production workloads — consider Azure OpenAI directly.

──────────────────────────────────────────────────

## Slide 10 — Output Options

AI Builder Custom Prompts support multiple output types:

| Output Type | Use When |
|---|---|
| **Text** | Simple summaries, free-form responses |
| **JSON** | ✅ **Recommended default.** Structured data you can parse in subsequent flow steps |
| **Documents** | Generating formatted documents from AI output |

**Other input types to explore:**
- 📄 Text — raw text input
- 🖼️ Images — pass images for analysis
- 📑 PDF — extract and analyse PDF content
- 🗃️ Dataverse records — pull records directly as input

*Explore these based on your use case — the AI Hub has templates to get you started.*

──────────────────────────────────────────────────

## Slide 11 — Best Practices: Building Reliable AI Flows

### 🏗️ 1. Always Enforce JSON Contracts

Never rely on free-text output from the LLM. Always define a JSON schema and validate the response.

Why? Because LLMs are non-deterministic — the same prompt can produce different output structures. JSON gives you a contract you can parse and validate programmatically.

### 🧪 2. Start with Error Handling (Not After)

Don't build the happy path and add error handling later. **Build error handling from Day 1.**

LLMs will produce unexpected output. It's not a question of *if*, it's *when*.

### ⚡ 3. Fail Fast

In multi-step AI flows, if one step produces bad output, **stop the flow immediately**. Don't waste resources processing garbage through 5 more AI steps.

> **Analogy:** If the first ingredient is rotten, don't keep cooking the meal. Throw it out and start over.

### 🔍 4. Validate Output Before Proceeding

Add conditions after every AI Builder step:

| Check | Action |
|---|---|
| Output length < minimum threshold (e.g., 50 chars) | → Reject & log |
| JSON schema is empty or malformed | → Reject & log |
| Required fields are missing or null | → Reject & log |
| Quality flags fail (e.g., confidence score too low) | → Reject & log |
| Output passes all checks | → ✅ Proceed to next step |

### 💾 5. Log Failures

When a step fails or gets rejected:
- Save the error details (input, output, reason for rejection)
- Don't just silently swallow errors
- Use this data to improve your prompts over time

### 🔄 6. Consider Retry Logic

Some failures are intermittent — the model might return truncated output once but succeed on retry. Build in a retry mechanism (1–2 retries) before giving up entirely.

──────────────────────────────────────────────────

## Slide 12 — Error Handling Pattern: Visual

```
┌─────────────────────┐
│   AI Builder Step    │
│   (Custom Prompt)    │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   Validate Output   │
│   - Length check     │
│   - Schema check    │
│   - Quality flags   │
└──────────┬──────────┘
           │
     ┌─────┴─────┐
     │            │
  ✅ Pass      ❌ Fail
     │            │
     ▼            ▼
┌──────────┐ ┌──────────────┐
│ Continue │ │ Log Error    │
│ Flow     │ │ + Terminate  │
│          │ │ (Fail Fast)  │
└──────────┘ └──────────────┘
```

**Key principle:** Every AI step should be followed by a validation gate. No exceptions.

──────────────────────────────────────────────────

## Slide 13 — Copilot Studio: When You Need an Agent

**What is Copilot Studio?**

Copilot Studio lets you build AI-powered conversational agents (chatbots with brains). These agents can:
- 💬 Converse with users in natural language
- 🔌 Connect to your data sources (SharePoint, Dataverse, websites, APIs)
- 🧠 Use generative AI to answer questions from your knowledge base
- 🔧 Trigger actions (Power Automate flows, connectors, plugins)
- 🌐 Deploy across Teams, websites, and other channels

**Think of it as:**
> Power Automate = automated workflows that run in the background
> Copilot Studio = an AI agent that users interact with directly

──────────────────────────────────────────────────

## Slide 14 — Copilot Studio: Key Capabilities

| Capability | What It Does |
|---|---|
| **Generative Answers** | Point the agent at a knowledge source (SharePoint, website, docs) and it answers questions from that content |
| **Topics & Triggers** | Define specific conversation paths for known intents |
| **Plugin Actions** | Call Power Automate flows, connectors, or custom APIs mid-conversation |
| **Autonomous Triggers** | Agents can be triggered by events, not just user messages |
| **Multi-channel Deployment** | Teams, web, Slack, custom apps |
| **Authentication** | Integrate with Entra ID for secure, role-based interactions |
| **Orchestration** | Chain multiple AI steps, tools, and data sources in a single agent |

──────────────────────────────────────────────────

## Slide 15 — When to Use What: Copilot Studio vs Power Automate AI Builder

| Scenario | Use This | Why |
|---|---|---|
| Automated background processing (no user interaction) | **Power Automate + AI Builder** | Runs on triggers, no conversation needed |
| User needs to ask questions and get AI-powered answers | **Copilot Studio** | Conversational interface, knowledge grounding |
| Processing emails/documents on arrival | **Power Automate + AI Builder** | Event-driven, no user in the loop |
| Internal helpdesk / FAQ bot | **Copilot Studio** | Natural language Q&A from knowledge base |
| Multi-step data pipeline with AI analysis | **Power Automate + AI Builder** | Sequential flow with validation gates |
| Agent that takes actions on behalf of users | **Copilot Studio** | Can call APIs, create records, trigger workflows |
| Scheduled batch processing with AI | **Power Automate + AI Builder** | Scheduled triggers, batch operations |
| Interactive data exploration with AI | **Copilot Studio** | Conversational, context-aware follow-ups |

### Things Copilot Studio Can Do That AI Builder Cannot:
- 🗣️ **Conversational context** — maintains conversation history across turns
- 📚 **Knowledge grounding** — automatically retrieves relevant info from your data sources
- 🤖 **Autonomous actions** — agent decides what tools/actions to use based on user intent
- 🔄 **Multi-turn reasoning** — handles complex, multi-step conversations
- 🌐 **Multi-channel deployment** — same agent works in Teams, web, etc.
- 👤 **User-facing AI** — designed for direct human interaction

### Things AI Builder Does Better:
- ⚙️ **Background automation** — no user interaction required
- 📋 **Structured pipelines** — step-by-step processing with validation
- 🔗 **Deep flow integration** — native in Power Automate with 1000+ connectors
- 💰 **Simpler cost model** — pay per token, predictable

──────────────────────────────────────────────────

## Slide 16 — Copilot Studio: Best Practices

### 📚 1. Ground Your Agent in Quality Data
The agent is only as good as the knowledge you give it. Curate your SharePoint sites, docs, and data sources.

### 🎯 2. Define Clear Scope
Tell the agent what it should and shouldn't answer. A focused agent beats a "knows everything badly" agent every time.

### 🧪 3. Test with Real Users Early
What makes sense to you might confuse everyone else. Get real users testing early and often.

### 🔒 4. Secure Your Agent
Use authentication. Scope data access. Don't build an agent that accidentally exposes sensitive information to the wrong audience.

### 📊 5. Monitor & Iterate
Use Copilot Studio analytics to see what users are asking, where the agent fails, and improve over time.

──────────────────────────────────────────────────

## Slide 17 — Example Use Cases: Power Automate + AI Builder

*[Space for project screenshots and demos]*

### Example 1: Daily Performance Report Analysis
- **Trigger:** Scheduled daily
- **Input:** Power BI report data export
- **AI Step:** Custom Prompt analyses trends, flags risks and opportunities
- **Validation:** JSON schema check, minimum content length, quality flags
- **Output:** Structured insights pushed to dashboard / emailed to stakeholders

### Example 2: Document Review Automation
- **Trigger:** New document uploaded to SharePoint
- **AI Step:** Custom Prompt reviews document against policy/criteria
- **Validation:** Schema validation, completeness check
- **Output:** Analysis report routed to review team via Teams

### Example 3: Email Triage & Categorisation
- **Trigger:** New email arrives in shared mailbox
- **AI Step:** Custom Prompt classifies email by topic, urgency, sentiment
- **Validation:** Check classification fields are populated, confidence threshold
- **Output:** Email routed to correct team, tagged in system

*[Add your own project examples here]*

──────────────────────────────────────────────────

## Slide 18 — Example Use Cases: Copilot Studio

*[Space for project screenshots and demos]*

### Example 1: Internal Knowledge Assistant
- **Channel:** Microsoft Teams
- **Knowledge Sources:** SharePoint document libraries, internal wiki
- **Capability:** Employees ask questions in natural language, agent retrieves and summarises relevant information
- **Actions:** Can create support tickets, escalate to humans

### Example 2: Project Status Agent
- **Channel:** Teams / Web
- **Knowledge Sources:** Dataverse, Project tracking system
- **Capability:** Stakeholders ask "What's the status of Project X?" and get real-time answers
- **Actions:** Can trigger status update flows, send notifications

### Example 3: Onboarding Buddy
- **Channel:** Teams
- **Knowledge Sources:** HR policies, onboarding docs, IT setup guides
- **Capability:** New starters ask questions about processes, tools, policies
- **Actions:** Can book meetings, submit IT requests, link to training

*[Add your own project examples here]*

──────────────────────────────────────────────────

## Slide 19 — Getting Started: Your First Steps

### Power Automate + AI Builder
1. Open Power Automate → navigate to **AI Hub**
2. Explore pre-built models to understand what's available
3. Create a **Custom Prompt** — start simple (summarise text, classify an email)
4. Define JSON output schema from the start
5. Add validation conditions after the AI step
6. Test with real data, iterate on the prompt

### Copilot Studio
1. Go to **copilotstudio.microsoft.com**
2. Create a new agent
3. Add a knowledge source (start with a single SharePoint site)
4. Test in the built-in chat
5. Add topics for specific conversation paths
6. Deploy to Teams for wider testing

### Both Platforms
- Start small — prove value with one use case before scaling
- Document your prompts and learnings
- Share what works (and what doesn't) with your team

──────────────────────────────────────────────────

## Slide 20 — Summary & Key Takeaways

| Principle | Detail |
|---|---|
| **JSON over text** | Always enforce structured output contracts |
| **Fail fast** | Don't process bad output through multi-step pipelines |
| **Validate everything** | Add quality gates after every AI step |
| **Start cheap** | Use the smallest model that works, upgrade only if needed |
| **Error handling first** | Build for failure from Day 1 |
| **Right tool for the job** | Power Automate for background automation, Copilot Studio for user-facing agents |
| **Iterate** | Your first prompt will not be your best. That's normal. |

**Resources:**
- AI Hub in Power Automate
- Copilot Studio: copilotstudio.microsoft.com
- Microsoft Learn: AI Builder documentation
- Microsoft Learn: Copilot Studio documentation

──────────────────────────────────────────────────

*Questions? Let's talk.*
