# AI in Low Code: Making Power Platform Actually Intelligent
*A guide to AI Builder, Copilot Studio, and knowing which one won't bankrupt your project*

──────────────────────────────────────────────────

## The Low-Code AI Landscape

Power Platform has 3 AI tools that actually matter:

| Tool | What It Is | Where It Runs |
|------|-----------|---------------|
| **AI Builder** | Turnkey AI actions (LLM prompts, data extraction) embedded in Power Automate/Apps | Inside PA flows, Agent flows, Power Apps |
| **Copilot Studio** | Conversational agent that orchestrates tools, data, and prompts | Copilot Studio, Dataverse/M365 integrations |
| **Azure AI Foundry** | Full Azure platform for accessing, evaluating, hosting, and fine-tuning LLMs | Azure subscription, via connectors or HTTP |

Today we focus on the first two. Azure AI Foundry is the "break glass in case of emergency" option when low-code isn't enough.

──────────────────────────────────────────────────

## AI Builder — What It Actually Is

AI Builder is "GPT-in-a-box" for citizen developers. No Python. No deployment. No existential crisis. Just drag an action into your flow and configure a prompt.

**Core Capabilities:**

| Capability | Description | Common Use |
|-----------|-------------|------------|
| Create text with GPT | Generate/analyse/transform text using LLM prompts | Summaries, classifications, insights |
| Document processing | Extract data from invoices, receipts, forms | Accounts payable, compliance |
| Image analysis | Describe, classify, or extract info from images | Site inspections, asset tracking |
| Sentiment analysis | Determine tone/sentiment of text | Customer feedback, survey analysis |
| Entity extraction | Pull structured data from unstructured text | Email parsing, report mining |
| Custom models | Train classification or object detection models | Domain-specific categorisation |

──────────────────────────────────────────────────

## AI Builder — The Good, The Bad, The Expensive

| ✅ The Good | ❌ The Bad | 💸 The Expensive |
|------------|-----------|-----------------|
| No code needed | Limited customisation | 3-40× Azure OpenAI pricing |
| Built-in governance & compliance | Token limits per call | Credits disappear fast |
| Native Power Platform integration | No streaming responses | Premium license required |
| Fast to prototype | Can't choose specific model versions | Cost scales linearly with volume |
| Citizen developers can use it | Limited error detail on failures | No volume discounts |
| Auto-handles auth & endpoints | Prompt debugging is painful | Budget surprises are common |

──────────────────────────────────────────────────

## AI Builder — Best Practices

### 1. Always Output JSON
- Easier to parse in Power Automate (Parse JSON action)
- Enables schema validation (did the model return what you asked for?)
- Makes logging structured and queryable
- Avoids the "I got a nice paragraph but can't do anything with it" problem

### 2. Split Complex Tasks
- Token limits are real — don't try to analyse a 50-page document in one call
- Break into: extract → analyse → summarise → format
- Each step is independently testable and debuggable

### 3. Use the Right Model Tier
- **Standard models**: Simple classification, formatting, extraction, structural checks
- **Premium/Reasoning models**: Multi-source analysis, mathematical verification, conflict detection, complex judgement
- Don't pay reasoning-model prices for tasks a standard model handles fine

### 4. Include Examples in Prompts
- Few-shot prompting (2-3 examples) dramatically improves consistency
- Show the model what good output looks like
- Include edge cases in examples

### 5. Validate Outputs — Never Trust Blindly
- Check JSON schema (required fields present?)
- Check data types (numbers are numbers, not strings?)
- Check length (truncated output?)
- Cross-reference cited values against source data

### 6. Monitor Credit Usage
- Set alerts at 80% of monthly allowance
- Track cost per flow run
- Calculate ROI: time saved × hourly rate > AI Builder cost?

### 7. Version Your Prompts
- Store prompts in SharePoint with versioning enabled
- Never hardcode prompts in flows
- Tag prompt versions in logs so you can correlate quality changes

──────────────────────────────────────────────────

## AI Builder — Prompt Design

A well-structured prompt has five components:

| Component | Purpose | Example |
|-----------|---------|---------|
| **Role** | Set the model's expertise and persona | "You are a mining operations analyst for Rio Tinto" |
| **Context** | Provide background the model needs | "You are analysing daily production data for an iron ore mine" |
| **Task** | Exactly what you want done | "Identify the top 3 performance variances and explain root causes" |
| **Format** | How you want the output structured | "Return JSON with fields: variance, magnitude, root_cause, recommendation" |
| **Constraints** | What to avoid or consider | "Only cite metrics present in the source data. Do not fabricate values." |

**Example prompt:**
```
Role: You are a mining operations analyst specialising in iron ore production.

Context: You are reviewing daily production performance data for a Rio Tinto mine site.
The data includes planned vs actual values for key metrics.

Task: Identify the top 3 most significant performance variances. For each, provide:
- The metric name and variance percentage
- A root cause analysis based on the data
- One actionable recommendation

Format: Return JSON array:
[
  {
    "metric": "string",
    "variance_pct": number,
    "root_cause": "string",
    "recommendation": "string"
  }
]

Constraints:
- Only reference metrics present in the provided data
- Do not fabricate or estimate values
- If fewer than 3 significant variances exist, return fewer
```

**Pro Tip:** Store prompts in SharePoint, not hardcoded in flows. Version history = free prompt management. Swap prompt files for A/B testing without touching the flow.

──────────────────────────────────────────────────

## AI Builder — Dynamic Inputs

Avoid hardcoding prompts and config. Use external sources for flexibility.

### SharePoint-Driven Prompts
1. Store system prompt as a text file in SharePoint
2. Store rules/context as separate files
3. In your flow: Get File Content → Compose → AI Builder
4. Benefits: version history, easy updates, no flow changes needed

### Config Lists
Store thresholds, feature flags, and variant configs in SharePoint lists or Dataverse:

| Config Item | Where to Store | Why |
|------------|---------------|-----|
| Prompt templates | SharePoint files | Version history, easy editing |
| Quality thresholds | SharePoint list / Dataverse | Change without redeployment |
| Feature flags | SharePoint list / Dataverse | Enable/disable per site or role |
| Model selection | Dataverse | Swap models without flow changes |

──────────────────────────────────────────────────

## Copilot Studio — What It Actually Is

Copilot Studio is a conversational AI agent builder. It orchestrates tools, data, and prompts via natural language.

Think of it this way:
- **AI Builder** = the worker (does specific tasks)
- **Copilot Studio** = the manager (decides what tasks to do, in what order, based on conversation)

**Key Capabilities:**

| Capability | Description |
|-----------|-------------|
| Topic-based routing | Route conversations to specific logic based on user intent |
| Action calling | Call Power Automate flows, HTTP endpoints, Dataverse operations |
| Multi-turn conversations | Maintain context across conversation turns |
| Adaptive cards | Rich interactive responses (buttons, forms, tables) |
| Channel deployment | Deploy to Teams, web, Slack, etc. |
| Knowledge sources | Ground responses in uploaded documents, websites, SharePoint |
| Guardrails | Control what the agent should and shouldn't do |

──────────────────────────────────────────────────

## Copilot Studio — Best Practices

### 1. Design Topics Around User Intents
- Think "what is the user trying to accomplish?" not "what can my system do?"
- Map common questions/tasks to specific topics
- Avoid catch-all topics that try to do everything

### 2. Each Action Returns Structured JSON
- Copilot variables pass data between steps
- Structured output = predictable behaviour
- Unstructured output = unpredictable agent responses

### 3. Keep Actions Focused
- One action = one job
- Small, composable actions > large monolithic flows
- Easier to debug, test, and reuse

### 4. Use Fallback Topics
- What happens when the agent doesn't understand?
- Graceful failure > confused silence
- Offer alternatives: "I didn't understand that. Did you mean X or Y?"

### 5. Test with Real Users Early
- Your "obvious" UX isn't obvious to anyone else
- Watch someone use it without guidance — you'll learn fast
- Iterate on phrasing, topic triggers, and response formatting

### 6. Log Conversation Turns to Dataverse
- Track what users ask (reveals gaps in your topics)
- Track what the agent gets wrong (reveals prompt issues)
- Build analytics on usage patterns

### 7. Set Guardrails
- What should the agent refuse to do?
- What data should it never expose?
- What should trigger escalation to a human?

──────────────────────────────────────────────────

## Copilot Studio — Agent Patterns

### Pattern 1: Generate → Evaluate → Display

| Step | Action | Description |
|------|--------|-------------|
| 1 | User asks a question | Natural language input |
| 2 | Call Generator Flow | Power Automate flow with AI Builder, returns draft |
| 3 | Call Evaluator Flow | Separate flow validates the draft against source data |
| 4 | Check verdict | If PASS → display. If FAIL → retry with feedback (max 2) |
| 5 | Display result | Adaptive card with result and source link |

### Pattern 2: Multi-Step Agent

| Step | Action | Description |
|------|--------|-------------|
| 1 | Copilot parses intent | Understands what the user wants |
| 2 | Get data | Power Automate flow retrieves relevant data from Dataverse/SharePoint |
| 3 | Analyse | AI Builder action analyses the data |
| 4 | Validate | Separate AI Builder action validates the analysis |
| 5 | Display | Adaptive card with validated result and source links |

### Pattern 3: Tool Orchestration

The agent decides which tools to use based on the conversation:

| Tool Type | Purpose | Example |
|-----------|---------|---------|
| Retrieval | Fetch relevant data before generation | Query Dataverse for site performance data |
| Generation | Create analysis/content from data | AI Builder prompt to generate insights |
| Validation | Verify generated content | Separate evaluator checks accuracy |
| Logging | Record conversation and decisions | Write to Dataverse for audit trail |

──────────────────────────────────────────────────

## When to Use Which?

### Decision Matrix

| Scenario | AI Builder | Copilot Studio | Both Together |
|----------|:---------:|:--------------:|:------------:|
| Automated batch processing (no user) | ✅ | | |
| User-facing Q&A | | ✅ | |
| Document analysis pipeline | ✅ | | |
| Interactive data explorer | | | ✅ |
| Automated email/report generation | ✅ | | |
| Helpdesk / IT support bot | | ✅ | |
| Complex multi-step workflow with user input | | | ✅ |
| Simple text classification | ✅ | | |
| Conversational data entry | | ✅ | |
| Triggered by schedule or event | ✅ | | |
| Triggered by user conversation | | ✅ | |

### Rules of Thumb

| If... | Then Use... |
|-------|------------|
| No user interaction needed | AI Builder in Power Automate |
| User needs to have a conversation | Copilot Studio |
| User triggers a complex background process | Copilot Studio calls AI Builder flows |
| You need fine control over every step | AI Builder in Power Automate |
| You need the agent to decide what to do | Copilot Studio with tool orchestration |
| You're prototyping quickly | AI Builder (faster to set up) |
| You're building a production assistant | Copilot Studio + AI Builder flows |

──────────────────────────────────────────────────

## Example Use Case: Daily Performance Insights (DPI)

### The Problem
Mining operations teams need daily AI-generated insights from performance data across 11 sites. Manual analysis takes hours and is inconsistent.

### The Solution
AI Builder pipeline in Power Automate using Pattern 4 (Task Decomposition with Layered Validation).

### Pipeline Summary

| Stage | Model Tier | Purpose |
|-------|-----------|---------|
| Derived Metrics | Reasoning | Calculate composite metrics from raw data |
| Claim Generator | Reasoning | Analyse full dataset, generate structured insight claims |
| Claim Validator | Reasoning | Verify every claim's maths and traceability against source |
| Suggestion Generator | Standard | Generate 3-6 actionable suggestions per validated claim |
| Suggestion Validator | Standard | Validate each suggestion independently |
| Reassembly | None (deterministic) | Recompose claims with only validated suggestions |
| Quality Gate | Reasoning | Cross-claim conflict detection, structural checks |
| Reranker | Standard | Rank by safety → severity → variance magnitude |
| HTML Formatter | Standard | Convert to responsive HTML email |
| Format Validator | Standard | Validate HTML structure and completeness |

### Key Results
- 22 email variants/day (11 sites × 2 roles)
- Fail-fast saves ~30% downstream token cost
- Per-suggestion validation catches 1-2 bad suggestions per digest
- Logs pinpoint exactly which layer and component failed

### Key Learnings
- Separate generation from evaluation — always
- Store prompts externally for easy iteration
- Validators must form independent judgements (no upstream CoT passed)
- Start simple (Pattern 1), evolve based on log evidence

──────────────────────────────────────────────────

## Example Use Case: Operations Assistant Agent

### The Problem
Site teams need quick answers from multiple data sources without navigating 5 different systems.

### The Solution
Copilot Studio agent with tool orchestration, deployed in Teams.

### Agent Design

| Component | Implementation | Purpose |
|-----------|---------------|---------|
| Intent recognition | Copilot Studio topics | Route user questions to correct logic |
| Data retrieval | Power Automate flows | Query Dataverse, SharePoint, APIs |
| Analysis | AI Builder actions | Generate insights from retrieved data |
| Validation | Separate AI Builder action | Verify analysis against source |
| Response | Adaptive cards | Rich display with source links |
| Logging | Dataverse write | Audit trail and usage analytics |

### Key Learnings
- Keep actions small and composable
- Always show data sources in responses (builds trust)
- Fallback gracefully when data isn't available
- Log conversation turns — reveals what users actually need vs what you built

──────────────────────────────────────────────────

## Cost Reality Check 💸

### Pricing Comparison

| Task | Azure OpenAI Direct | AI Builder | Markup |
|------|:------------------:|:----------:|:------:|
| Simple text analysis (1K tokens) | $0.0005 | $0.02 | 40× |
| Document processing (10K tokens) | $0.005 | $0.20 | 40× |
| Complex analysis (50K tokens) | $0.025 | $1.00 | 40× |
| High-volume processing (1M tokens) | $0.50 | $20.00 | 40× |

### Cost Strategy

| Phase | Approach |
|-------|---------|
| **Prototype / POC** | AI Builder — fast setup, low volume, cost acceptable |
| **Pilot (< 100 ops/month)** | AI Builder — convenience outweighs cost premium |
| **Production (> 1000 ops/month)** | Migrate to Azure OpenAI — cost savings justify development effort |
| **High-volume production** | Azure OpenAI mandatory — AI Builder costs are prohibitive |

### Budget Tips
1. Calculate expected monthly usage before starting
2. Set credit consumption alerts at 80%
3. Use standard models where possible (save premium for reasoning)
4. Track cost per flow run in logs
5. Calculate ROI: (manual hours saved × hourly rate) > AI Builder cost?

──────────────────────────────────────────────────

## Getting Started — Your First 30 Minutes

| Step | Time | Action |
|------|------|--------|
| 1 | 2 min | Open Power Automate, create an instant cloud flow |
| 2 | 5 min | Add "Create text with GPT using a prompt" action |
| 3 | 10 min | Write a simple prompt (summarise text, classify an email, extract key points) |
| 4 | 5 min | Test with sample data |
| 5 | 5 min | Add error handling (Scope + Configure Run After) |
| 6 | 3 min | Celebrate — you just built AI without writing code |

──────────────────────────────────────────────────

## Key Takeaways

1. **AI Builder** = AI actions in flows (batch, automated, no user interaction)
2. **Copilot Studio** = conversational agents (interactive, user-facing)
3. **Use both together** for complex solutions (agent calls flows)
4. **Always validate AI outputs** — never trust blindly
5. **Start simple, iterate based on evidence** — don't over-engineer day one
6. **Watch costs** — prototype with AI Builder, scale with Azure OpenAI
7. **Store prompts externally** — version, iterate, A/B test without touching flows
8. **Log everything that matters** — you can't improve what you can't measure

──────────────────────────────────────────────────
END OF PRESENTATION
